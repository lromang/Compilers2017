**************************************************
## Nombre: Luis Manuel Román García
## CU: 000117077
**************************************************

### Proyecto Compiladores: Entrega 1

En esta entrega se desarrollo un preprocesador que eliminara comentarios y sustituyera macros, del mismo modo se construyó un escaner que reconociera los *lexemas* del lenguaje y regresara el nombre del token asociado así cómo su valor. 

### Compilación

Para compilar el proyecto basta correr `make` 

### Pruebas 

Las pruebas se pueden realizar de la siguiente manera: 

`./dcc < samples/archivo_que_se_desea_probar.frag`
